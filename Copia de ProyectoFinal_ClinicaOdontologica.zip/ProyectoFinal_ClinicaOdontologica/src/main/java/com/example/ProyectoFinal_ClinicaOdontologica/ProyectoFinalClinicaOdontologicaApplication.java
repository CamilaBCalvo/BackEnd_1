package com.example.ProyectoFinal_ClinicaOdontologica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProyectoFinalClinicaOdontologicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalClinicaOdontologicaApplication.class, args);
	}

}
