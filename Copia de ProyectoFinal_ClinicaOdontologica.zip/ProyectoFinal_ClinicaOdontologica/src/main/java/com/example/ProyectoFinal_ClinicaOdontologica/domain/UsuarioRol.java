package com.example.ProyectoFinal_ClinicaOdontologica.domain;

public enum UsuarioRol {
    ROLE_USER
}
