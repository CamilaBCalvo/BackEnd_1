package com.example.ProyectoFinal_ClinicaOdontologica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalClinicaOdontologicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
