package com.example.ProyectoFinal_ClinicaOdontologica.exceptions;

public class ResourceNotFoundException extends Exception{
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
